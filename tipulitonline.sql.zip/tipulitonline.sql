-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 11 2011 г., 11:59
-- Версия сервера: 5.1.30
-- Версия PHP: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `tipulitonline`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `f_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_user_id` int(11) NOT NULL,
  `f_video_id` int(11) NOT NULL,
  `f_improvement` set('Yes','No') NOT NULL,
  `f_difficulty` set('Hard','Suitable','Easy') NOT NULL,
  `f_difficulty_text` text,
  `f_suggestions` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `feedback`
--


-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `n_datetime` datetime NOT NULL,
  `n_title` varchar(250) NOT NULL,
  `n_body` text NOT NULL,
  `n_status_id` tinyint(4) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `news`
--


-- --------------------------------------------------------

--
-- Структура таблицы `news_status`
--

CREATE TABLE IF NOT EXISTS `news_status` (
  `ns_id` int(11) NOT NULL AUTO_INCREMENT,
  `ns_status` varchar(45) NOT NULL,
  PRIMARY KEY (`ns_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `news_status`
--

INSERT INTO `news_status` (`ns_id`, `ns_status`) VALUES
(1, 'New'),
(2, 'Visible'),
(3, 'Hidden'),
(4, 'Pending'),
(5, 'Deleted');

-- --------------------------------------------------------

--
-- Структура таблицы `privat_messages`
--

CREATE TABLE IF NOT EXISTS `privat_messages` (
  `spm_id` int(11) NOT NULL AUTO_INCREMENT,
  `spm_from_user_id` int(11) DEFAULT NULL,
  `spm_from_teacher_id` int(11) DEFAULT NULL,
  `spm_to_user_id` int(11) DEFAULT NULL,
  `spm_to_teacher_id` int(11) DEFAULT NULL,
  `spm_subject` varchar(250) NOT NULL DEFAULT 'No subject',
  `spm_body` text NOT NULL,
  `spm_datetime` datetime NOT NULL,
  `spm_is_new` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`spm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `privat_messages`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__alerts`
--

CREATE TABLE IF NOT EXISTS `system__alerts` (
  `sa_id` int(11) NOT NULL AUTO_INCREMENT,
  `sa_alert_type_id` tinyint(3) NOT NULL,
  `sa_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `system__alerts`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__alert_type`
--

CREATE TABLE IF NOT EXISTS `system__alert_type` (
  `sat_id` int(11) NOT NULL AUTO_INCREMENT,
  `sat_type` varchar(100) NOT NULL,
  PRIMARY KEY (`sat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `system__alert_type`
--

INSERT INTO `system__alert_type` (`sat_id`, `sat_type`) VALUES
(1, 'New User Registration'),
(2, 'Update User Information');

-- --------------------------------------------------------

--
-- Структура таблицы `system__email_templates`
--

CREATE TABLE IF NOT EXISTS `system__email_templates` (
  `set_id` int(11) NOT NULL AUTO_INCREMENT,
  `set_subject` varchar(250) NOT NULL,
  `set_body` text NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `system__email_templates`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__email_validation`
--

CREATE TABLE IF NOT EXISTS `system__email_validation` (
  `sev_id` int(11) NOT NULL AUTO_INCREMENT,
  `sev_reg_request_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sev_user_id` int(11) NOT NULL,
  `sev_validation_code` varchar(255) NOT NULL,
  `sev_pass` varchar(45) NOT NULL,
  PRIMARY KEY (`sev_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Дамп данных таблицы `system__email_validation`
--

INSERT INTO `system__email_validation` (`sev_id`, `sev_reg_request_time`, `sev_user_id`, `sev_validation_code`, `sev_pass`) VALUES
(9, '2011-03-03 12:07:29', 24, '1cd186dd34a7efc306b40a7f999efbf8', 'qwqwqwqw'),
(10, '2011-03-03 12:13:47', 25, '44d7da771324a06fdab22ad67484e31e', 'qwqwqwqw'),
(11, '2011-03-03 12:21:27', 26, 'b49cca6cd17862b9cd47249f816d9976', 'qwqwqwqw'),
(12, '2011-03-03 12:51:26', 27, '18918296a23dd6fa705eb60652488edd', 'qwqwqwqw'),
(13, '2011-03-03 13:08:39', 28, 'a578af2e29d9fc2366d30bb5b3f0be80', 'bobikov22'),
(14, '2011-03-03 16:38:38', 29, 'ecfe3244f45070431bb95cac898a72a6', 'qwqwqwqw'),
(15, '2011-03-04 13:49:44', 30, 'd12b11f6720618a24c34195cd9d12c9f', 'qwqwqwqw'),
(16, '2011-03-04 19:50:08', 31, '50cf5599391b70d16c945b3a6ba46c93', 'qwqwqwqw'),
(17, '2011-03-04 20:35:58', 33, '459460dd03146ad3c060e253afc2ba6c', 'qwqwqwqw'),
(18, '2011-03-04 20:36:42', 34, '64671688ec53164472bb380249eec926', 'qwqwqwqw'),
(19, '2011-03-05 07:07:43', 35, '2efe983d4706ea4b1ad8a5e8c95a52c0', 'qwqwqwqw'),
(20, '2011-03-05 10:41:21', 36, 'cefffaefb1b14006bcc9d67c0eabac14', 'qwqwqwqw'),
(21, '2011-03-05 17:08:54', 37, '19d4ea3915899d6d90b036792fcca5b9', 'qwqw'),
(22, '2011-03-06 06:48:47', 38, 'e8696cfd2ca23bbff041acfd7befddab', 'qwqwqw'),
(23, '2011-03-09 12:17:50', 39, '7d75df03b685349fb749069e64332b46', 'qwqw'),
(24, '2011-03-09 13:42:49', 40, 'e87f8952454ea7a2be284dc8acd16c62', 'qwqw'),
(25, '2011-03-09 14:12:16', 41, '2085cfed226e4fc493eeee56b091fb2d', 'qwqw'),
(26, '2011-03-09 15:40:52', 42, '9f8def9b4c1580528dba79c1357ddd23', 'qwqw'),
(27, '2011-03-09 15:45:59', 43, 'cb5c4920154e52039487927fb599b3c0', 'qwqw'),
(28, '2011-03-09 15:54:49', 44, 'db5f222619173f3022049536d68ef08f', 'qwqw'),
(29, '2011-03-09 16:02:11', 45, '42febf1d2da3d2ecab7728c8a1efa0e5', 'qwqw'),
(30, '2011-03-09 16:09:32', 46, '3da50003180b05e457e4270ef95d1898', 'qwqwqw'),
(31, '2011-03-09 16:13:32', 47, '99379ac7ed06c78b5b56ee0ee9795f3f', 'qwqw'),
(32, '2011-03-09 16:34:57', 48, '013c33642649c5fcf724f6724022fb63', 'qwqw'),
(33, '2011-03-09 16:45:08', 49, 'e40dee5b1afb02ef52bd0544fcd5d730', 'qwqw'),
(34, '2011-03-09 17:13:11', 50, '0bd68dc8111fd50e1767cdae7a4f1fa7', 'qwqw'),
(35, '2011-03-09 17:14:17', 51, 'fb1337805824513b67ce79a9ebbd57b8', 'qwqw'),
(36, '2011-03-09 18:26:28', 52, '575bea21b092aa7331a7fd1a85e45915', 'qwqw'),
(37, '2011-03-09 21:36:46', 53, '027153bfc0ad7f223752ac2c0a03795d', 'qwqw'),
(38, '2011-03-10 10:29:49', 54, '80efe41514e64be74591aa5804a107ea', 'qwqw'),
(39, '2011-03-10 11:14:46', 55, 'dc457ea6178d43ce0d0516160cf68642', 'qwqw'),
(40, '2011-03-10 15:36:07', 56, '7d5f86d7d9c17b8a7bc79238aee8bb7e', 'qwqw'),
(41, '2011-03-10 16:54:05', 57, '28cf768cfd9d3acc66b09ac387afd43c', 'qwqw'),
(42, '2011-03-10 17:10:08', 58, 'f93ebee2e2a5d0face772cb54a110134', 'qwqw'),
(43, '2011-03-11 07:11:47', 59, '0a6e175a64654ccf624b216cddca894e', 'qwqw'),
(44, '2011-03-11 07:49:39', 60, 'd61a20cd61c7c5ca0bed5a27c46eb6b2', 'qwqw'),
(45, '2011-03-11 07:50:12', 61, 'baebe58deee54b5d2e32ca3faa49daf7', 'qwqw'),
(46, '2011-03-11 07:51:01', 62, '1a7b548fe2979c6a3e7b3708db7db6e1', 'qwqw'),
(47, '2011-03-11 07:51:39', 63, '215fb8aad22afaad6dd9368373c6a6ec', 'qwqw'),
(48, '2011-03-11 10:46:56', 64, 'ddeb3ad976779765f3ceb71c5d6c086c', 'qwqw'),
(49, '2011-03-11 11:57:12', 65, '04d5037f91fd6a7eee1874dce7a44cb7', 'qwqw');

-- --------------------------------------------------------

--
-- Структура таблицы `system__language`
--

CREATE TABLE IF NOT EXISTS `system__language` (
  `sl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sl_language` varchar(60) NOT NULL,
  PRIMARY KEY (`sl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `system__language`
--

INSERT INTO `system__language` (`sl_id`, `sl_language`) VALUES
(1, 'Hebrew'),
(2, 'English'),
(3, 'Arabic');

-- --------------------------------------------------------

--
-- Структура таблицы `system__log`
--

CREATE TABLE IF NOT EXISTS `system__log` (
  `sl_id` varchar(200) NOT NULL,
  `sl_ip` int(11) NOT NULL,
  `sl_user_id` int(11) NOT NULL,
  `sl_login_time` int(11) NOT NULL,
  `sl_logout_time` int(11) DEFAULT NULL,
  `sl_playing_time_1` int(11) DEFAULT NULL,
  `sl_playing_time_2` int(11) DEFAULT NULL,
  PRIMARY KEY (`sl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `system__log`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__sex`
--

CREATE TABLE IF NOT EXISTS `system__sex` (
  `ss_id` int(11) NOT NULL AUTO_INCREMENT,
  `ss_sex` varchar(10) NOT NULL,
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `system__sex`
--

INSERT INTO `system__sex` (`ss_id`, `ss_sex`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `t_first_name` varchar(250) NOT NULL,
  `t_last_name` varchar(250) NOT NULL,
  `t_email` varchar(255) NOT NULL,
  `t_pass` varchar(255) NOT NULL,
  `t_sex_id` tinyint(1) DEFAULT NULL,
  `t_language_id` tinyint(4) DEFAULT NULL,
  `t_style` text,
  `t_skype` varchar(200) DEFAULT NULL,
  `t_facebook` varchar(255) DEFAULT NULL,
  `t_phone` varchar(20) DEFAULT NULL,
  `t_url` varchar(255) DEFAULT NULL,
  `t_picture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `teachers`
--


-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(100) NOT NULL,
  `u_family_name` varchar(100) NOT NULL,
  `u_status_id` tinyint(3) NOT NULL,
  `u_registraion_date` date NOT NULL,
  `u_address` varchar(255) DEFAULT NULL,
  `u_state_id` smallint(5) DEFAULT NULL,
  `u_zip` varchar(10) DEFAULT NULL,
  `u_country_id` tinyint(3) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_email` varchar(255) NOT NULL,
  `u_sex_id` tinyint(1) DEFAULT NULL,
  `u_date_of_birth` date DEFAULT NULL,
  `u_external_emails` enum('Yes','No') DEFAULT 'No',
  `u_visits_amount` int(11) DEFAULT NULL,
  `u_picture` varchar(255) DEFAULT NULL,
  `u_registration_stamp` int(11) NOT NULL,
  `u_objectives` text,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`u_id`, `u_name`, `u_family_name`, `u_status_id`, `u_registraion_date`, `u_address`, `u_state_id`, `u_zip`, `u_country_id`, `u_password`, `u_email`, `u_sex_id`, `u_date_of_birth`, `u_external_emails`, `u_visits_amount`, `u_picture`, `u_registration_stamp`, `u_objectives`) VALUES
(59, 'Dima', 'Borgit', 4, '2011-03-11', '', 1, NULL, 1, 'qwqw', 'tenhi@mail.ru', NULL, NULL, NULL, 0, NULL, 3333, 'Dima22dsfsdf'),
(61, 'sdfsdf', 'dfgdfgdg', 4, '2011-03-11', '', 1, NULL, 1, 'qwqw', 'fsdfs@mail.ru', NULL, '2011-03-02', NULL, 0, NULL, 3333, NULL),
(62, 'sdfsdf', 'dfgdfgdg', 4, '2011-03-11', '', 1, NULL, 1, 'qwqw', 'fsdfsw@mail.ru', 0, '2011-03-02', NULL, 0, NULL, 3333, NULL),
(63, 'sdfsdf', 'dfgdfgdg', 4, '2011-03-11', 'Charkow', 1, NULL, 1, 'qwqw', 'fsdfsw22@mail.ru', 1, '2011-03-02', NULL, 0, NULL, 3333, NULL),
(64, 'aaaa', 'ssss', 4, '2011-03-11', '', 1, NULL, 1, 'qwqw', 'dfsfs@web.de', 1, '2011-03-07', NULL, 0, NULL, 3333, NULL),
(65, 'sfsdf', 'dfgdfg', 4, '2011-03-11', '', 1, NULL, 1, 'qwqw', 'sdfsdfs@web.de', NULL, NULL, NULL, 0, NULL, 3333, 'dfgdf');

-- --------------------------------------------------------

--
-- Структура таблицы `user__health_table`
--

CREATE TABLE IF NOT EXISTS `user__health_table` (
  `uht_id` int(11) NOT NULL AUTO_INCREMENT,
  `uht_user_id` int(11) NOT NULL,
  `uht_height` double DEFAULT NULL,
  `uht_weight` double DEFAULT NULL,
  `uht_bmi` double DEFAULT NULL,
  `uht_pregnant` set('Yes','No') DEFAULT NULL,
  `uht_pregnant_since` tinyint(4) DEFAULT NULL,
  `uht_walk` set('Yes','No') DEFAULT NULL,
  `uht_sit` set('Yes','No') DEFAULT NULL,
  `uht_hands` set('Yes','No') DEFAULT NULL,
  `uht_slipped_disk` set('Yes','No') DEFAULT NULL,
  `uht_ankles_and_feet` set('Yes','No') DEFAULT NULL,
  `uht_knees` set('Yes','No') DEFAULT NULL,
  `uht_thighs_or_pelvis` set('Yes','No') DEFAULT NULL,
  `uht_lower_back` set('Yes','No') DEFAULT NULL,
  `uht_upper_back` set('Yes','No') DEFAULT NULL,
  `uht_neck_and_shoulders` set('Yes','No') DEFAULT NULL,
  `uht_head` set('Yes','No') DEFAULT NULL,
  `uht_wrists` set('Yes','No') DEFAULT NULL,
  `uht_elbows` set('Yes','No') DEFAULT NULL,
  `uht_other_pain_body` text,
  `uht_depression_or_anxiety` set('Yes','No') DEFAULT NULL,
  `uht_heart_or_pb` set('Yes','No') DEFAULT NULL,
  `uht_injury` set('Yes','No') DEFAULT NULL,
  `uht_injury_text` text,
  `uht_epilepsy` set('Yes','No') DEFAULT NULL,
  `uht_cancer` set('Yes','No') DEFAULT NULL,
  `uht_diabetes` set('Yes','No') DEFAULT NULL,
  `uht_asthma` set('Yes','No') DEFAULT NULL,
  `uht_Artritis` set('Yes','No') DEFAULT NULL,
  `uht_hernia` set('Yes','No') DEFAULT NULL,
  `uht_medication` set('Yes','No') DEFAULT NULL,
  `uht_other_conditions` text,
  PRIMARY KEY (`uht_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Дамп данных таблицы `user__health_table`
--

INSERT INTO `user__health_table` (`uht_id`, `uht_user_id`, `uht_height`, `uht_weight`, `uht_bmi`, `uht_pregnant`, `uht_pregnant_since`, `uht_walk`, `uht_sit`, `uht_hands`, `uht_slipped_disk`, `uht_ankles_and_feet`, `uht_knees`, `uht_thighs_or_pelvis`, `uht_lower_back`, `uht_upper_back`, `uht_neck_and_shoulders`, `uht_head`, `uht_wrists`, `uht_elbows`, `uht_other_pain_body`, `uht_depression_or_anxiety`, `uht_heart_or_pb`, `uht_injury`, `uht_injury_text`, `uht_epilepsy`, `uht_cancer`, `uht_diabetes`, `uht_asthma`, `uht_Artritis`, `uht_hernia`, `uht_medication`, `uht_other_conditions`) VALUES
(48, 59, 120, 20, NULL, 'No', NULL, 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', NULL, 'Suffer info', 'Yes', 'Yes', NULL, 'Medications info', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', NULL, 'reat info'),
(49, 60, 120, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(50, 61, 120, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(51, 62, 120, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(52, 63, 120, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(53, 64, 120, 20, NULL, 'Yes', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(54, 65, 120, 20, NULL, NULL, 1, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', NULL, '', '', '', NULL, '', '', '', '', '', '', '', NULL, '');

-- --------------------------------------------------------

--
-- Структура таблицы `user__status`
--

CREATE TABLE IF NOT EXISTS `user__status` (
  `us_id` int(11) NOT NULL AUTO_INCREMENT,
  `us_type` varchar(45) NOT NULL,
  PRIMARY KEY (`us_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `user__status`
--

INSERT INTO `user__status` (`us_id`, `us_type`) VALUES
(1, 'Premium'),
(2, 'Subscription'),
(3, 'Free'),
(4, '6D'),
(5, 'Open'),
(6, 'Close');

-- --------------------------------------------------------

--
-- Структура таблицы `video__6d`
--

CREATE TABLE IF NOT EXISTS `video__6d` (
  `v6d_id` int(11) NOT NULL AUTO_INCREMENT,
  `v6d_code` varchar(100) NOT NULL,
  PRIMARY KEY (`v6d_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `video__6d`
--

INSERT INTO `video__6d` (`v6d_id`, `v6d_code`) VALUES
(1, 'code1'),
(2, 'code2'),
(3, 'code3'),
(4, 'code4'),
(5, 'code5'),
(6, 'code6'),
(7, 'code7');

-- --------------------------------------------------------

--
-- Структура таблицы `video__6d_status`
--

CREATE TABLE IF NOT EXISTS `video__6d_status` (
  `v6ds_id` int(11) NOT NULL AUTO_INCREMENT,
  `v6ds_video_id` tinyint(3) NOT NULL,
  `v6ds_user_id` int(11) NOT NULL,
  `v6ds_teacher_id` int(11) NOT NULL,
  `v6ds_viewed` set('Yes','No') DEFAULT 'No',
  PRIMARY KEY (`v6ds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `video__6d_status`
--


-- --------------------------------------------------------

--
-- Структура таблицы `video__all_movies`
--

CREATE TABLE IF NOT EXISTS `video__all_movies` (
  `vam_id` int(11) NOT NULL AUTO_INCREMENT,
  `vam_video_player1` varchar(100) DEFAULT NULL,
  `vam_video_player2` text,
  `vam_teacher_id` int(11) NOT NULL,
  `vam_user_id` int(11) NOT NULL,
  `vam_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vam_is_payed` set('Yes','No') DEFAULT 'No',
  `vam_playing_duration` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `video__all_movies`
--

