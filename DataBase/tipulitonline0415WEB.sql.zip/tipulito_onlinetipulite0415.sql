-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 15 2011 г., 16:42
-- Версия сервера: 5.0.92
-- Версия PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `tipulito_online`
--

-- --------------------------------------------------------

--
-- Структура таблицы `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `chat_id` int(11) NOT NULL auto_increment,
  `chat_from_user_id` int(11) default NULL,
  `chat_from_teacher_id` int(11) default NULL,
  `chat_to_user_id` int(11) default NULL,
  `chat_to_teacher_id` int(11) default NULL,
  `chat_message` text NOT NULL,
  `chat_datetime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `chat_isread_s` tinyint(4) default '0',
  `chat_isread_t` tinyint(4) default '0',
  PRIMARY KEY  (`chat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=425 ;

--
-- Дамп данных таблицы `chat`
--

INSERT INTO `chat` (`chat_id`, `chat_from_user_id`, `chat_from_teacher_id`, `chat_to_user_id`, `chat_to_teacher_id`, `chat_message`, `chat_datetime`, `chat_isread_s`, `chat_isread_t`) VALUES
(418, 72, NULL, NULL, 1, 'I have finished the 6d course', '2011-04-14 19:41:35', 1, 1),
(419, 72, NULL, NULL, 1, '<img src=''/i/smiles/ugly.gif'' alt=''ugly''/><img src=''/i/smiles/ugly.gif'' alt=''ugly''/>', '2011-04-14 19:41:35', 1, 1),
(420, NULL, 1, 72, NULL, 'New chat request', '2011-04-14 19:42:07', 1, 1),
(421, NULL, 1, 72, NULL, '<img src=''/i/smiles/good.gif'' alt=''good''/>', '2011-04-14 19:42:07', 1, 1),
(422, 73, NULL, NULL, 1, '<span style="font-weight: bold;">×™×© ×ž×™×©×”×•?</span>', '2011-04-14 21:36:07', 1, 1),
(423, NULL, 1, 73, NULL, 'Im currently offline. I will read your message by my next visit', '2011-04-14 21:36:07', 1, 1),
(424, NULL, 1, 73, NULL, 'New chat request', '2011-04-14 21:38:37', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `f_id` int(11) NOT NULL auto_increment,
  `f_user_id` int(11) NOT NULL,
  `f_video_id` varchar(200) NOT NULL,
  `f_improvement` set('Yes','No') NOT NULL,
  `f_difficulty` set('Hard','Suitable','Easy') NOT NULL,
  `f_difficulty_text` text,
  `f_suggestions` varchar(250) default NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`f_id`, `f_user_id`, `f_video_id`, `f_improvement`, `f_difficulty`, `f_difficulty_text`, `f_suggestions`) VALUES
(27, 72, '3', 'Yes', 'Suitable', 'The video number 3 was realy cool', '');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `n_id` int(11) NOT NULL auto_increment,
  `n_datetime` datetime NOT NULL,
  `n_title` varchar(250) NOT NULL,
  `n_body` text NOT NULL,
  `n_status_id` tinyint(4) NOT NULL,
  PRIMARY KEY  (`n_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `news`
--


-- --------------------------------------------------------

--
-- Структура таблицы `news_status`
--

CREATE TABLE IF NOT EXISTS `news_status` (
  `ns_id` int(11) NOT NULL auto_increment,
  `ns_status` varchar(45) NOT NULL,
  PRIMARY KEY  (`ns_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `news_status`
--

INSERT INTO `news_status` (`ns_id`, `ns_status`) VALUES
(1, 'New'),
(2, 'Visible'),
(3, 'Hidden'),
(4, 'Pending'),
(5, 'Deleted');

-- --------------------------------------------------------

--
-- Структура таблицы `privat_messages`
--

CREATE TABLE IF NOT EXISTS `privat_messages` (
  `spm_id` int(11) NOT NULL auto_increment,
  `spm_from_user_id` int(11) default NULL,
  `spm_from_teacher_id` int(11) default NULL,
  `spm_to_user_id` int(11) default NULL,
  `spm_to_teacher_id` int(11) default NULL,
  `spm_subject` varchar(250) NOT NULL default 'No subject',
  `spm_body` text NOT NULL,
  `spm_datetime` datetime NOT NULL,
  `spm_is_new` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`spm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=257 ;

--
-- Дамп данных таблицы `privat_messages`
--

INSERT INTO `privat_messages` (`spm_id`, `spm_from_user_id`, `spm_from_teacher_id`, `spm_to_user_id`, `spm_to_teacher_id`, `spm_subject`, `spm_body`, `spm_datetime`, `spm_is_new`) VALUES
(239, NULL, 1, NULL, NULL, '?????? ????? ???????? ???????', 'Dima×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '2011-04-14 17:28:23', 0),
(240, NULL, 1, 72, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', 'Dima×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '2011-04-14 17:36:42', 1),
(241, NULL, 1, 72, NULL, '×§×•×¨×¡ × ×¤×ª×— ×¢×‘×•×¨×š â€“ ×©× ×” ××ª ×—×™×™×š ×‘ â€“ 20 ×“×§', '×©×œ×•× ×¨×‘,<br/><br/>×× ×• ×©×ž×—×™× ×œ×”×•×“×™×¢×š ×©×§×•×¨×¡ ×©×©×ª ×”×ž×¤×’×©×™× × ×¤×ª×— ×‘×¢×‘×•×¨×š ×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×©×œ "×˜×™×¤×•×œ×™×ª <br/>××•× ×œ×™×™×Ÿ". ××•×¨×š ×›×œ ×ª×¨×’×•×œ ×”×•× ×› â€“ 20 ×“×§''  ×œ×ž×©×š ×©×™×©×” ×©×™×¢×•×¨×™×. ×”×§×•×¨×¡ ×‘× ×•×™ ×‘×”×“×¨×’×” ×•×›×œ <br/>×©×™×¢×•×¨ ×ž×ª×‘×¡×¡ ×¢×œ ×©×™×¢×•×¨ ×§×•×“×.<br/><br/>×¦×¤×• ×‘×¡×¨×˜×•×Ÿ ×”×”×“×¨×›×” ×•×ª×¨×’×œ×• ××ª ×›×•×œ×•, ×›×š ×™×—×›×” ×œ×›× ×”×ª×¨×’×•×œ ×”×‘× ×™×•× ×œ×ž×—×¨×ª. ×œ×”×©×’×ª ×ž×™×¨×‘ <br/>×”×™×¢×™×œ×•×ª, ×ª×¨×’×œ×• ××ª ×”×§×•×¨×¡ ×‘×ž×©×š <b>6 ×™×ž×™× ×¨×¦×•×¤×™× â€“ ×™×•× ××—×¨×™ ×™×•× </b>×× × ×™×ª×Ÿ. ×‘×›×œ ×¤×¢× <br/>×ª×©×œ×— ××œ×™×›× ×‘×ž×™×™×œ ×”×•×“×¢×”. <br/><br/>×œ×¤× ×™ ×©××ª× ×ž×ª×—×™×œ×™× ×œ×ª×¨×’×œ <b>×¢×œ×™×›× ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×‘× ×’×Ÿ ×”×ž×“×™×” ×”×ª×—×ª×•×Ÿ </b>×‘×ž×¨×›×– ×”×œ×ž×™×“×”<br/>×©× ×ž×—×›×” ×œ×›× ×¡×¨×˜×•×Ÿ ×”×“×¨×›×” ×¢×œ ×”× ×—×™×•×ª ×œ×ª×¨×’×•×œ ×‘×‘×™×ª. ××– ×ª×•×›×œ×• ×œ×§×‘×•×¢ ××ª ×”×¡×‘×™×‘×” ×•×”×–×ž×Ÿ <br/>×”× ×•×—×™× ×œ×›× ×•×œ×”×›×™×Ÿ ××ª×›× ×œ×ª×¨×’×•×œ ×‘×‘×™×ª.<br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/>×œ×™×“×™×¢×ª×›×:<br/>1 ×”×©×ª×ª×¤×•×ª ×‘×§×•×¨×¡ ×”×™× ×‘×”×¡×›×ž×” ×œ×ª×§× ×•×Ÿ ×¢×œ×™×• ×”×¡×›×ž×ª× ×¢× ×”×¨×™×©×•× ×œ×ž×¨×›×– ×”×œ×ž×™×“×”.<br/>2 ×‘×ž×™×“×” ×•×”×ª×¨×’×•×œ ×’×•×¨× ×œ×›× ×œ×›××‘, ×”×¤×¡×™×§×• ×œ×ª×¨×’×œ ××ª ×”×ª×¨×’×•×œ ×”×ž×¡×•×™×. ×ª×¨×’×œ×• ×¨×§ ×ž×” <br/>×©× ×•×— ×œ×›×. ×‘×¦×¢×• ××ª ×”×”×¨×¤×™×” ×”×¡×•×¤×™×ª <b>×•×‘×¡×™×•× ×”×ª×¨×’×•×œ ×¤× ×• ××œ×™× ×•</b>. × ×¡×™×™×¢ ×œ×›× ×œ×”×ª××™×<br/>×ª×¨×’×•×œ ×¢×‘×•×¨×›×.<br/>3 ×× ×—×©×ª× ×©×”×§×•×¨×¡ ×§×œ ×ž×“×™ ××• ×§×©×” ×ž×“×™, ×ª× ×• ×œ× ×• ×ž×©×•×‘ ×‘××ž×¦×¢×•×ª ×ž×¨×›×– ×”×œ×ž×™×“×” ×•× ×©×ž×— ×œ×”×ª××™× ×œ×›× ×ª×¨×’×•×œ ××™×©×™ ×ž×•×ª×× ×œ×¦×¨×›×™×›×.<br/><br/>×‘×‘×¨×›×ª ×©×œ×•×,<br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:22:06', 1),
(242, NULL, 1, 72, NULL, '×ª×¨×’×•×œ ×ž×¡'' 2 ×ž×•×›×Ÿ ×‘×©×‘×™×œ×š', '×©×œ×•× ×¨×‘,<br/><br/>×œ××—×¨ ×©×¦×¤×™×ª ×•×ª×¨×’×œ×ª ××ª ×”×©×™×¢×•×¨ ×”×¨××©×•×Ÿ ×× ×• ×¤×•× ×™× ×œ×ª×¨×’×•×œ ×”×©× ×™. ×›×¤×™ ×©×¨××™×ª, ×”×ª×¨×’×•×œ<br/>×©× ×™×ª×Ÿ ×œ×š ×”×•× ×¨×š ×•×ž×¢×ž×™×§. ×–×”×• ×§×•×¨×¡ ×¨×™×¤×•×™ ×¢×¦×ž×™, ×”×ž×©×¤×¨ ××™×›×•×ª ×”×—×™×™× ×•×ž×¢×•×“×“ ×¨×’×™×¢×”. ×–×”×• <br/>×§×•×¨×¡ × ×¤×œ× ×œ×¤×ª×•×— ××™×ª×• ××ª ×”×™×•× ×•×× ×• ×ž×ž×œ×™×¦×™× ×œ×¤× ×•×ª ×–×ž×Ÿ ×•×œ×ª×¨×’×œ ××•×ª×• <b>×‘×‘×•×§×¨</b><br/><br/>×× ×• ×ž×–×›×™×¨×™× ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×§×•×©×™ ××• ×›××‘ ×”×ž×•×¤×™×¢×™× ×‘×–×ž×Ÿ ×”×ª×¨×’×•×œ. <b>×”×ª×¨×’×•×œ ××™× ×• ××ž×•×¨ </b><br/><b>×œ×’×¨×•× ×œ×›××‘ ××‘×œ ×¢×©×•×™ ×œ×¢×•×¨×¨ ×ž××ž×¥ ×©×œ ×¢×‘×•×“×” ×¢× ×”×’×•×£</b>â€“ ×œ×”×‘×“×™×œ ×‘×™×Ÿ ×›××‘ ×œ×ž××ž×¥ × ×›×•×Ÿ  <br/>×–×•×”×™ ××—×ª ×ž×”×ª×•×‘× ×•×ª ×©×ž×ª×¨×’×œ ×™×•×’×” ×œ×•×ž×“ ×‘×¢×¦×ž×•. ×‘×ž×™×“×” ×•×§×™×™× ×§×•×©×™ ×œ×”×‘×“×™×œ ×‘×™× ×™×”×, ×¤× ×• <br/><br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/>×‘×‘×¨×›×ª ×©×œ×•×,<br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:24:20', 1),
(243, NULL, 1, 72, NULL, '×ª×¨×’×•×œ ×ž×¡'' 3 ×ž×•×›×Ÿ ×‘×©×‘×™×œ×š', '×©×œ×•× ×œ×š,<br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/>×”×™×•× × ×©×™× ×œ×‘ ×œ×§×©×¨ ×©×‘×™×Ÿ ×ª× ×•×¢×” ×œ× ×©×™×ž×”. ×”×™×•× ×’× × ×›×™×¨ ××ª ×ª× ×•×—×” ×‘×©× "×›×œ×‘ ×ž×¡×ª×›×œ <br/>×œ×ž×˜×”". ×–×•×”×™ ×ª× ×•×—×ª ×ž×¤×ª×— ×‘×™×•×’×” ×”×ž×—×–×§×ª ×•×ž×’×ž×™×©×” ××ª ×›×œ ×”×’×•×£. ×ž×ª×¨×’×œ×™× ××•×ª×” ×ž×ª×—×™×œ×™× <br/>×•×ž×ª×§×“×ž×™× ×›××—×“.<br/><br/><b>×× ×• ×ž×–×›×™×¨×™× ×œ×›× ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×§×•×©×™ ××• ×›××‘ ×©×—×©×™× ×‘×–×ž×Ÿ ×”×ª×¨×’×•×œ. </b><br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×©×œ× ×• ×™×© ×’× ×ª×¨×’×œ×™ × ×©×™×ž×”, ×©×œ×™×˜×” ×× ×¨×’×˜×™×ª (×¤×¨×× ×™××ž×”) ×•×”×¨×¤×™×” ×‘×¦×¤×™×™×” <br/>×—×•×¤×©×™×ª ×œ×œ× ×ª×©×œ×•×. ×›×ž×• ×›×Ÿ ×™×© ×ž×™×“×¢ ××•×“×•×ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×•×©×™×œ×•×‘×” ×‘×—×™×™×. ××¤×©×¨ ×•×ž×•×ž×œ×¥ <br/>×œ×ª×¨×’×œ ×ª×¨×’×•×œ×™× ××œ×” ×‘×ž×§×‘×™×œ ×œ×§×•×¨×¡.<br/><br/>×‘×‘×¨×›×ª ×©×œ×•×,<br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:25:00', 1),
(244, NULL, 1, 72, NULL, '×ª×¨×’×•×œ ×ž×¡'' 4 ×ž×•×›×Ÿ ×‘×©×‘×™×œ×š', '×”×§×•×¨×¡ × ×‘× ×” ×©×œ×‘ ××—×¨×™ ×©×œ×‘ ×¢×œ ×ž× ×ª ×œ×©×¤×¨ ×ª×—×•×©×” ×˜×•×‘×” ×‘×’×•×£, ×œ×”×¨×¤×•×ª ×ž×§×•×ž×•×ª ×‘×”× <br/>×”×¦×˜×‘×¨ ×ž×ª×— ×•×œ×”× ×™×¢ ×× ×¨×’×™×™×ª ×—×™×™× (×¤×¨×× ×” â€“ Prana) ×œ××•×¨×š ×”×’×•×£. ×”×™×•×’×” ×™×™×—×•×“×™×ª ×‘×›×š ×©×”×™× <br/>×ž×œ×•×•×” ×¢×§×¨×•× ×•×ª ×©×œ ×ž×•×“×¢×•×ª, × ×©×™×ž×” × ×›×•× ×” ×•×¨×™×›×•×– ×™×—×“ ×¢× ×ª× ×•×¢×•×ª ×•×ª× ×•×—×•×ª ×”×ž×¨×’×™×¢×•×ª <br/>×•×ž×¨×¤××•×ª.<br/><br/><b>×× ×”×’×¢×ª ×¢×“ ×”×œ×•×, ×¢×©×”/×™ ×ž××ž×¥ ×œ×”×©×œ×™× ××ª ×”×§×•×¨×¡ ×¢×“ ×¡×•×¤×•.</b>××¤×©×¨ ×œ×”×¨×’×™×© ×‘×©×™× ×•×™ <br/>×”×ž×¦×˜×‘×¨ ×™×•× ××—×¨×™ ×™×•×.<br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/>×‘×‘×¨×›×ª ×©×œ×•×,<br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:25:59', 1),
(245, 72, NULL, NULL, 1, '×ž×©×•×‘ ×¢×œ ×ª×¨×’×•×œ', '<br/>You''ve got following feedback from Dima Kolbin according to the video: 3:<br/><br/>Improvement: Yes<br/><br/>Difficulty: Suitable<br/><br/>His comments to the difficulty: The video number 3 was realy cool<br/><br/>His suggestions: <br/><br/>', '2011-04-14 19:25:59', 1),
(246, NULL, 1, 72, NULL, '×ª×¨×’×•×œ ×ž×¡'' 5 ×ž×•×›×Ÿ ×‘×©×‘×™×œ×š', '×× ×ª×¨×’×œ×ª ×™×•× ××—×¨×™ ×™×•× ×”×©×™× ×•×™ ×›×‘×¨ ×ž×ª×¨×—×©. ×”×’×•×£ ×ž×’×™×‘ ×˜×•×‘ ×›××©×¨ ×ž×˜×¤×œ×™× ×‘×• ×‘×ž×¡×™×¨×•×ª <br/>×•×‘×¢×“×™× ×•×ª. ×ª×¨×’×•×œ ×”×§×•×¨×¡ ×”×¤×¢× ×ž×’×™×¢ ×œ×”×¢×ž×§×” ×’×“×œ×” ×™×•×ª×¨ ×‘×ª× ×•×¢×•×ª ××¤×§×˜×™×‘×™×•×ª ×”×¤×•×ª×—×•×ª ××ª <br/>×‘×™×ª ×”×—×–×” ×•×ž×©×¤×¨×•×ª ××ª ×”×§×©×¨ ×©×‘×™×Ÿ ×”××’×Ÿ ×œ×¨×’×œ×™×™×. ××œ×• ×”× ×©× ×™ ×”×—×œ×§×™× ×”×ž×©×ž×¢×•×ª×™×™× <br/>×‘×™×•×ª×¨ ×œ×ª× ×•×¢×” ×©×œ× ×• ×‘×ž×¨×—×‘. × ×ª×¨×’×œ ×”×™×•× ×‘×ž×¡×™×¨×•×ª ×•×‘×”×¢×ž×§×”. × × ×©×•× ×¢× ×”×ª× ×•×¢×•×ª ×•× ×”×™×” <br/>×§×©×•×‘×™× ×œ×ž×¦×‘ ×”×’×•×£.<br/><br/><b>×× ×”×’×¢×ª ×¢×“ ×”×œ×•×, ×¢×©×” ×ž××ž×¥ ×•×”×©×œ× ××ª ×”×§×•×¨×¡.</b>××¤×©×¨ ×œ×”×¨×’×™×© ×‘×©×™× ×•×™ ×× ×”×•× <br/>×ž×¦×˜×‘×¨ ×™×•× ××—×¨×™ ×™×•×.<br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:26:50', 1),
(247, NULL, 1, 72, NULL, 'Re: ×ž×©×•×‘ ×¢×œ ×ª×¨×’×•×œ', '<span style="font-weight: bold;">Nice job.</span> <span style="color: rgb(0, 255, 51);">Kee</span><span style="text-decoration: underline; color: rgb(0, 255, 51);">p on wor</span><span style="color: rgb(0, 255, 51);">k</span>ing <br>', '2011-04-14 19:28:58', 1),
(248, NULL, 1, 72, NULL, 'Last task', '<span style="color: rgb(255, 0, 51); font-weight: bold;">Have u done my last task</span><span style="font-weight: bold;">?</span><br>', '2011-04-14 19:35:50', 1),
(249, NULL, 1, 72, NULL, '×ª×¨×’×•×œ ×ž×¡'' 6 ×ž×•×›×Ÿ ×‘×©×‘×™×œ×š', '×–×”×• ×”×ª×¨×’×•×œ ×”×ž×¡×›× ×©×œ ×”×§×•×¨×¡. ×× ×• ×ž×‘×¨×›×™× ××•×ª×š ×©×”×’×¢×ª ×œ×©×œ×‘ ×–×”. ×× ×ª×¨×’×œ×ª ×™×•× ××—×¨×™ ×™×•×, ×¦×‘×¨×ª ×ª×¨×’×•×œ ×ž×¦×˜×‘×¨ ×•×”×¨×’×œ×ª ××ª ×¢×¦×ž×š ×œ×”×§×“×™×© ×–×ž×Ÿ ×œ×™×•×’×”. ×–×”×• ××™× ×• ×“×‘×¨ ×©×œ ×ž×”-×‘×›×š.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©×œ× ×• ×™××¤×©×¨ ×œ×š ×œ×”×ž×©×™×š ×œ×”×¢×ž×™×§ ×‘×™×•×’×” ×•×œ×™×¦×•×§ ×ª×¨×’×•×œ ×ž×ª×§×“× ×™×•×ª×¨ ×œ×–×ž×Ÿ<br/>×©×¤×™× ×™×ª ×‘×ž×”×œ×š ×”×™×•×. ×’×•×¤×š ×™×•×“×” ×œ×š ×•××™×›×•×ª ×—×™×™×š ×ª×ž×©×™×š ×œ×”×©×ª×¤×¨. ××™×Ÿ ×›×ž×• ×”×™×•×’×” ×œ×ª×—×–×•×§×ª<br/>×’×•×£ ×©×•×˜×¤×ª ×•×œ×”×›×™× ×• ×œ××ª×’×¨×™ ×”×—×™×™×.<br/><br/><b>× ×©×ž×— ×œ×©×ž×•×¢ ×ž×ž×š ××™×š ×”×™×” ×”×§×•×¨×¡, ×—×•×•×™×•×ª ×©×¢×‘×¨×ª, ×”×ž×œ×¦×•×ª ×•×‘×§×©×•×ª.</b><br/>×× ×• ×¢×•×ž×“×™× ×œ×©×™×¨×•×ª×š ×œ×”×ž×©×š ×”×ª×¨×’×•×œ ×©×œ×š ×‘×ž×¨×›×– ×”×œ×ž×™×“×”. ××ª/×” ×ž×•×–×ž×Ÿ/×ª ×œ×‘×—×•×¨ ×—×‘×™×œ×ª<br/>×ª×¨×’×•×œ ×”×ž×ª××™×ž×” ×œ×¦×¨×›×™×š ×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×•×œ×”×ž×©×™×š ×œ×ª×¨×’×œ ×¢×™×ž× ×•.<br/><br/><a href=''http://lc.tipulitonline.co.il/''>×›× ×™×¡×” ×œ×ž×¨×›×– ×”×œ×ž×™×“×”</a><br/><br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•×œ× ×™×™×Ÿ<br/><a href=''http://lc.tipulitonline.co.il/''>www.tipulitonline.co.il</a><br/>', '2011-04-14 19:37:10', 1),
(250, NULL, 1, 73, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '×¨×•×¢×™×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '2011-04-14 21:33:09', 1),
(251, 73, NULL, NULL, 1, 'Re: ×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '×ª×•×“×” ×¢×œ ×”×ž×™×™×œ<br>', '2011-04-14 21:33:42', 1),
(252, NULL, 1, 73, NULL, 'Re: Re: ×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '××™×š ××¤×©×¨ ×œ×¢×–×•×¨ ×œ×š?<br>', '2011-04-14 21:43:05', 1),
(253, NULL, 1, 76, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '<p align=''right'' dir=''RTL''>Alice×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ</p>', '2011-04-15 14:29:10', 1),
(254, NULL, 1, 77, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '<p align=''right'' dir=''RTL''>×™×¤×¢×ª×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ</p>', '2011-04-15 15:27:30', 1),
(255, NULL, 1, 78, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '<p align=''right'' dir=''RTL''>×™×¤×¢×ª×©×œ×•×<br/>×× ×• ×ž×•×“×™× ×œ×š ×¢×œ ×”×¦×˜×¨×¤×•×ª×š ×œ×ž×¨×›×– ×”×œ×ž×™×“×” ×•×”×ª×¨×’×•×œ ×©×œ ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×”×¦×•×•×ª ×©×œ× ×• ×™×™×¦×•×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tiupulitonline.co.il''>info@tiupulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.lc.tipulitonline.co.il''></a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ</p>', '2011-04-15 15:28:26', 0),
(256, NULL, 1, 79, NULL, '×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ', '<p align=''right'' dir=''RTL''> Gmail ×©×œ×•×<br/>×‘×¨×•×›×™× ×”×‘××™× ×œ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ. ×ž×™×™×œ ×–×” × ×©×œ×— ×‘××•×¤×Ÿ ××•×˜×•×ž×˜×™ ×œ××—×¨ ×ž×™×œ×•×™ ×¤×¨×˜×™× ××™×©×™×™× ×‘××ª×¨ <br/>×¢×™×ž×š ×§×©×¨ ×‘×–×ž×Ÿ ×”×§×¨×•×‘ ×‘×›×“×™ ×œ×”×ª××™× ×œ×š ×ª×¨×’×•×œ ×™×•×’×” ××™×©×™.<br/><br/>×ž×¨×›×– ×”×œ×ž×™×“×” ×©× ×¤×ª×— ×‘×¢×‘×•×¨×š ×”×•× ×—×œ×•×Ÿ ×œ×¢×•×œ× ×©×œ ×™×“×¢ ××•×“×•×ª ×”×™×•×’×”. ×ž×˜×¨×ª×• ×©×œ ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ×”×•× ×œ×¢×•×“×“ ×•×œ×œ×ž×“ ×™×•×’×” ×‘×‘×™×ª ×•×œ×™×™×©× ××ª ×¢×§×¨×•× ×•×ª×™×” ×‘×—×™×™ ×”×™×•× ×™×•×. ×‘××ž×¦×¢×•×ª ×ž×¨×›×– <br/>×”×œ×ž×™×“×” ××¤×©×¨ ×œ×”×™×•×ª ×‘×§×©×¨ ×¢× ×ž×“×¨×™×›× ×• ×•×œ×¡×¤×§ ×ž×©×•×‘ ×¢×œ ××™×›×•×ª ×”×ª×¨×’×•×œ, ×”×¢×“×¤×•×ª ×•×‘×§×©×•×ª <br/>×ž×™×•×—×“×•×ª.<br/><br/>×‘×ž×¨×›×– ×”×œ×ž×™×“×” ×ž×—×›×” ×œ×š ×¢×ª×” ×¡×¨×˜×•×Ÿ ×”×¡×‘×¨ ×¨××©×•×Ÿ. ××ª/×” ×ž×•×–×ž× /×ª ×œ×¦×¤×•×ª ×‘×¡×¨×˜×•×Ÿ ×•×œ×™×™×©×  <br/>××ª ×¢×§×¨×•× ×•×ª ×”×™×•×’×” ×›×‘×¨ ×‘×ª×¨×’×•×œ ×”×¨××©×•×Ÿ.<br/><br/>×—×©×•×‘: ×¢×œ×™×š ×œ×”×•×“×™×¢ ×œ× ×• ×¢×œ ×›×œ ×©×™× ×•×™ ×‘×ž×¦×‘×š ×”×‘×¨×™××•×ª×™ ××• ×¢×œ ×›×œ ×¢× ×™×™×Ÿ ×’×•×¤× ×™ ××—×¨ ×”×§×©×•×¨ <br/>×œ×ª×¨×’×•×œ ×›×ž×• ×§×•×©×™ ×ž×™×•×—×“ ×‘×‘×™×¦×•×¢ ×”×ª×¨×’×™×œ×™×, ×›××‘ ××• ×ž×’×‘×œ×” ××—×¨×ª. × ×‘×§×© ×ž×ž×š ×œ×“×•×•×— ×¢×œ ×›×œ <br/>×©×™×¤×•×¨ ×©×—×œ ×‘×¢×§×‘×•×ª ×”×ª×¨×’×•×œ. ×”×™×•×’×” ×©×× ×• ×ž×œ×ž×“×™× ×ž×¢×•×¨×¨×ª ×›×•×—×•×ª ×¨×™×¤×•×™ ×¤× ×™×ž×™×™×. ××ª/×”  <br/>×ž×•×–×ž× ×™× ×œ×ª×¨×’×œ ×‘×§×‘×™×¢×•×ª ×•×œ×”×™×¢×–×¨ ×‘×ž×¨×›×– ×”×œ×ž×™×“×”.<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ ×¢×•×ž×“ ×œ×¨×©×•×ª×š ×‘×ž×™×™×œ: <a href=''info@tipulitonline.co.il''>info@tipulitonline.co.il</a><br/>×›×ª×•×‘×ª ×”××™× ×˜×¨× ×˜ ×©×œ× ×• ×”×™×: <a href=''http://www.tipulitonline.co.il''>tipulitonline.co.il</a>''<br/><br/>×‘×‘×¨×›×”,<br/><br/>×¦×•×•×ª ×˜×™×¤×•×œ×™×ª ××•× ×œ×™×™×Ÿ</p>', '2011-04-15 16:10:47', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `system__alerts`
--

CREATE TABLE IF NOT EXISTS `system__alerts` (
  `sa_id` int(11) NOT NULL auto_increment,
  `sa_student_id` int(11) default NULL,
  `sa_teacher_id` int(11) default NULL,
  `sa_alert_type_id` tinyint(3) NOT NULL,
  `sa_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`sa_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Дамп данных таблицы `system__alerts`
--

INSERT INTO `system__alerts` (`sa_id`, `sa_student_id`, `sa_teacher_id`, `sa_alert_type_id`, `sa_timestamp`) VALUES
(41, 72, NULL, 3, '2011-04-14 19:21:58'),
(42, 72, NULL, 4, '2011-04-14 19:25:59'),
(43, 73, NULL, 3, '2011-04-14 21:33:57');

-- --------------------------------------------------------

--
-- Структура таблицы `system__alert_type`
--

CREATE TABLE IF NOT EXISTS `system__alert_type` (
  `sat_id` int(11) NOT NULL auto_increment,
  `sat_type` varchar(100) NOT NULL,
  PRIMARY KEY  (`sat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `system__alert_type`
--

INSERT INTO `system__alert_type` (`sat_id`, `sat_type`) VALUES
(1, 'New User Registration'),
(2, 'Update User Information'),
(3, '6D Course Request'),
(4, 'Feedback from the student');

-- --------------------------------------------------------

--
-- Структура таблицы `system__email_templates`
--

CREATE TABLE IF NOT EXISTS `system__email_templates` (
  `set_id` int(11) NOT NULL auto_increment,
  `set_subject` varchar(250) NOT NULL,
  `set_body` text NOT NULL,
  PRIMARY KEY  (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `system__email_templates`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__email_validation`
--

CREATE TABLE IF NOT EXISTS `system__email_validation` (
  `sev_id` int(11) NOT NULL auto_increment,
  `sev_reg_request_time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `sev_user_id` int(11) NOT NULL,
  `sev_validation_code` varchar(255) NOT NULL,
  `sev_pass` varchar(45) NOT NULL,
  PRIMARY KEY  (`sev_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Дамп данных таблицы `system__email_validation`
--

INSERT INTO `system__email_validation` (`sev_id`, `sev_reg_request_time`, `sev_user_id`, `sev_validation_code`, `sev_pass`) VALUES
(58, '2011-04-14 17:35:13', 72, '07bd1839e61815b162a08f974ff65929', 'qwqw'),
(59, '2011-04-14 21:31:00', 73, '3d8487160f64cc1abcc22835ad3be4d9', '12345'),
(60, '2011-04-15 14:17:00', 74, '6cd34b3cd42a6eedbc3599cd6a756a1e', 'qwqw'),
(61, '2011-04-15 14:21:42', 75, 'f23e92e57b20af780a1739a20b946aad', 'qwqw'),
(62, '2011-04-15 14:23:45', 76, '0029641ba7d41c1c7dcce63dfe47a658', 'qwqw'),
(63, '2011-04-15 14:47:34', 77, '1b95b61bbffa23e6cad9fa23d32272d5', '12345'),
(64, '2011-04-15 15:18:43', 78, '318de0d82e5d9a903fdcd95a9c000cea', '12345'),
(65, '2011-04-15 16:10:19', 79, '7a6e7bc0a4d2293170209362969b6f4c', 'qwqw');

-- --------------------------------------------------------

--
-- Структура таблицы `system__language`
--

CREATE TABLE IF NOT EXISTS `system__language` (
  `sl_id` int(11) NOT NULL auto_increment,
  `sl_language` varchar(60) NOT NULL,
  PRIMARY KEY  (`sl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `system__language`
--

INSERT INTO `system__language` (`sl_id`, `sl_language`) VALUES
(1, 'Hebrew'),
(2, 'English'),
(3, 'Arabic');

-- --------------------------------------------------------

--
-- Структура таблицы `system__log`
--

CREATE TABLE IF NOT EXISTS `system__log` (
  `sl_id` varchar(200) NOT NULL,
  `sl_ip` int(11) NOT NULL,
  `sl_user_id` int(11) NOT NULL,
  `sl_login_time` int(11) NOT NULL,
  `sl_logout_time` int(11) default NULL,
  `sl_playing_time_1` int(11) default NULL,
  `sl_playing_time_2` int(11) default NULL,
  PRIMARY KEY  (`sl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `system__log`
--


-- --------------------------------------------------------

--
-- Структура таблицы `system__properties`
--

CREATE TABLE IF NOT EXISTS `system__properties` (
  `p_id` int(11) NOT NULL auto_increment,
  `p_name` varchar(250) NOT NULL,
  `p_value` text,
  PRIMARY KEY  (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `system__properties`
--

INSERT INTO `system__properties` (`p_id`, `p_name`, `p_value`) VALUES
(1, 'payment_info', '<table align="center" bgcolor="#FFFFFF" border="0" cellpadding="7" cellspacing="1" style="width: 620px;">\r\n	<tbody>\r\n		<tr>\r\n			<td bgcolor="#F48521" style="text-align: center;">\r\n				<span style="font-size:20px;"><span style="font-family: arial,helvetica,sans-serif;">×¤×” ×™×© ×›×•×ª×¨×ª</span></span></td>\r\n		</tr>\r\n		<tr>\r\n			<td bgcolor="#FFB448" style="text-align: center;">\r\n				×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜×¤×” ×™×© ×˜×§×¡×˜</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<iframe allowtransparency="true" frameborder="0" scrolling="no" src="https://www.tixwise.co.il/event/4067/24b17822ecd6b0c0d66eab9a6ae7397e5c1465765445?widget%5Bwidget%5D=1&amp;widget%5Bt_theme%5D=orange&amp;widget%5Bb_theme%5D=mouse&amp;widget%5Breffering_url%5D=http%3A%2F%2Ftipulitonline.co.il&amp;widget%5Bforward_to_url%5D=on&amp;widget%5Btarget%5D=top" style="border:none; overflow:hidden; width:600px; height:250px;"></iframe></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Структура таблицы `system__sex`
--

CREATE TABLE IF NOT EXISTS `system__sex` (
  `ss_id` int(11) NOT NULL auto_increment,
  `ss_sex` varchar(10) NOT NULL,
  PRIMARY KEY  (`ss_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `system__sex`
--

INSERT INTO `system__sex` (`ss_id`, `ss_sex`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `t_id` int(11) NOT NULL auto_increment,
  `t_first_name` varchar(250) NOT NULL,
  `t_last_name` varchar(250) NOT NULL,
  `t_lastactivity` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `t_visible` tinyint(4) default NULL,
  `t_email` varchar(255) NOT NULL,
  `t_pass` varchar(255) NOT NULL,
  `t_sex_id` tinyint(1) default NULL,
  `t_language_id` tinyint(4) default NULL,
  `t_style` text,
  `t_skype` varchar(200) default NULL,
  `t_facebook` varchar(255) default NULL,
  `t_phone` varchar(20) default NULL,
  `t_url` varchar(255) default NULL,
  `t_picture` varchar(255) default NULL,
  PRIMARY KEY  (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`t_id`, `t_first_name`, `t_last_name`, `t_lastactivity`, `t_visible`, `t_email`, `t_pass`, `t_sex_id`, `t_language_id`, `t_style`, `t_skype`, `t_facebook`, `t_phone`, `t_url`, `t_picture`) VALUES
(1, '×¦×•×•×ª', '××•× ×œ×™×™×Ÿ', '2011-04-15 15:17:38', 1, 'ereliroy@gmail.com', 'qwqw', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `u_id` int(11) NOT NULL auto_increment,
  `u_name` varchar(100) NOT NULL,
  `u_family_name` varchar(100) NOT NULL,
  `u_status_id` tinyint(3) NOT NULL,
  `u_registraion_date` date NOT NULL,
  `u_ip` varchar(20) default NULL,
  `u_ip_country` varchar(50) default NULL,
  `u_lastactivity` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `u_address` varchar(255) default NULL,
  `u_state_id` smallint(5) default NULL,
  `u_zip` varchar(10) default NULL,
  `u_country_id` tinyint(3) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_email` varchar(255) NOT NULL,
  `u_sex_id` tinyint(1) default NULL,
  `u_date_of_birth` date default NULL,
  `u_external_emails` enum('Yes','No') default 'No',
  `u_visits_amount` int(11) default '1',
  `u_picture` varchar(255) default NULL,
  `u_registration_stamp` int(11) NOT NULL,
  `u_objectives` text,
  PRIMARY KEY  (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`u_id`, `u_name`, `u_family_name`, `u_status_id`, `u_registraion_date`, `u_ip`, `u_ip_country`, `u_lastactivity`, `u_address`, `u_state_id`, `u_zip`, `u_country_id`, `u_password`, `u_email`, `u_sex_id`, `u_date_of_birth`, `u_external_emails`, `u_visits_amount`, `u_picture`, `u_registration_stamp`, `u_objectives`) VALUES
(72, 'Dima', 'Kolbin', 4, '2011-04-14', '94.179.108.236', 'UKRAINE', '2011-04-15 16:39:52', '', 1, NULL, 1, 'qwqw', 'tenhi@mail.ru', 1, '1978-12-04', 'Yes', 13, 'ava13027977613424.jpg', 3333, 'ooooo'),
(73, '×¨×•×¢×™', '× ×¡×™×•×Ÿ', 4, '2011-04-14', '79.179.207.205', 'ISRAEL', '2011-04-15 14:43:27', '×›×ª×•×‘×ª×™ 56', 1, NULL, 1, '54321', 'erelir@yahoo.com', 1, '1988-04-07', 'Yes', 5, NULL, 3333, '×× ×™ ×¨×•×¦×” ×ž×›×•× ×™×ª'),
(76, 'Alice', 'Cooper', 5, '2011-04-15', '94.179.119.133', 'UKRAINE', '2011-04-15 16:02:36', '', 1, NULL, 1, 'qwqw', 'tenhi@bk.ru', 1, '1959-05-05', 'Yes', 1, NULL, 3333, ''),
(77, '×™×¤×¢×ª', '×’×•×œ×“×ž×Ÿ', 5, '2011-04-15', '79.179.207.205', 'ISRAEL', '2011-04-15 15:33:37', '×™×¨×‘×•×¢ 12 ×‘××¨ ×©×‘×¢', 1, NULL, 1, '12345', 'ereliroy@walla.co.il', 0, '1971-04-01', 'Yes', 1, NULL, 3333, '×œ×”×¨×’×™×© ×˜×•×‘'),
(78, '×™×¤×¢×ª', '×©×¨×¨', 5, '2011-04-15', '79.179.207.205', 'ISRAEL', '2011-04-15 15:32:57', '×“×¨×š ×”×ž×œ×š 67', 1, NULL, 1, '12345', 'ifatgold@yahoo.com', 0, '1970-04-22', 'Yes', 1, NULL, 3333, '×ž×™ ××ª×'),
(79, 'Gmail', 'test', 5, '2011-04-15', '94.179.119.133', 'UKRAINE', '2011-04-15 16:37:01', '', 1, NULL, 1, 'qwqw', 'navigator1278@gmail.com', 0, '2011-04-05', 'Yes', 1, NULL, 3333, '');

-- --------------------------------------------------------

--
-- Структура таблицы `user__health_table`
--

CREATE TABLE IF NOT EXISTS `user__health_table` (
  `uht_id` int(11) NOT NULL auto_increment,
  `uht_user_id` int(11) NOT NULL,
  `uht_height` double default NULL,
  `uht_weight` double default NULL,
  `uht_bmi` double default NULL,
  `uht_pregnant` set('Yes','No') default NULL,
  `uht_pregnant_since` tinyint(4) default NULL,
  `uht_walk` set('Yes','No') default NULL,
  `uht_sit` set('Yes','No') default NULL,
  `uht_hands` set('Yes','No') default NULL,
  `uht_slipped_disk` set('Yes','No') default NULL,
  `uht_ankles_and_feet` set('Yes','No') default NULL,
  `uht_knees` set('Yes','No') default NULL,
  `uht_thighs_or_pelvis` set('Yes','No') default NULL,
  `uht_lower_back` set('Yes','No') default NULL,
  `uht_upper_back` set('Yes','No') default NULL,
  `uht_neck_and_shoulders` set('Yes','No') default NULL,
  `uht_head` set('Yes','No') default NULL,
  `uht_wrists` set('Yes','No') default NULL,
  `uht_elbows` set('Yes','No') default NULL,
  `uht_other_pain_body` text,
  `uht_depression_or_anxiety` set('Yes','No') default NULL,
  `uht_heart_or_pb` set('Yes','No') default NULL,
  `uht_injury` set('Yes','No') default NULL,
  `uht_injury_text` text,
  `uht_epilepsy` set('Yes','No') default NULL,
  `uht_cancer` set('Yes','No') default NULL,
  `uht_diabetes` set('Yes','No') default NULL,
  `uht_asthma` set('Yes','No') default NULL,
  `uht_Artritis` set('Yes','No') default NULL,
  `uht_hernia` set('Yes','No') default NULL,
  `uht_medication` set('Yes','No') default NULL,
  `uht_which_medication` text,
  `uht_migrene` set('Yes','No') default NULL,
  `uht_babies` set('Yes','No') default NULL,
  `uht_nosleep` set('Yes','No') default NULL,
  `uht_digestion` set('Yes','No') default NULL,
  `uht_menopause` set('Yes','No') default NULL,
  `uht_sclorosies` set('Yes','No') default NULL,
  `uht_headaches` set('Yes','No') default NULL,
  `uht_fatigue` set('Yes','No') default NULL,
  `uht_backashes` set('Yes','No') default NULL,
  `uht_breath` set('Yes','No') default NULL,
  `uht_ankles` set('Yes','No') default NULL,
  `uht_general1` varchar(250) default NULL,
  `uht_general2` varchar(250) default NULL,
  `uht_general3` varchar(250) default NULL,
  `uht_more_info` text,
  PRIMARY KEY  (`uht_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

--
-- Дамп данных таблицы `user__health_table`
--

INSERT INTO `user__health_table` (`uht_id`, `uht_user_id`, `uht_height`, `uht_weight`, `uht_bmi`, `uht_pregnant`, `uht_pregnant_since`, `uht_walk`, `uht_sit`, `uht_hands`, `uht_slipped_disk`, `uht_ankles_and_feet`, `uht_knees`, `uht_thighs_or_pelvis`, `uht_lower_back`, `uht_upper_back`, `uht_neck_and_shoulders`, `uht_head`, `uht_wrists`, `uht_elbows`, `uht_other_pain_body`, `uht_depression_or_anxiety`, `uht_heart_or_pb`, `uht_injury`, `uht_injury_text`, `uht_epilepsy`, `uht_cancer`, `uht_diabetes`, `uht_asthma`, `uht_Artritis`, `uht_hernia`, `uht_medication`, `uht_which_medication`, `uht_migrene`, `uht_babies`, `uht_nosleep`, `uht_digestion`, `uht_menopause`, `uht_sclorosies`, `uht_headaches`, `uht_fatigue`, `uht_backashes`, `uht_breath`, `uht_ankles`, `uht_general1`, `uht_general2`, `uht_general3`, `uht_more_info`) VALUES
(72, 72, 185, 93, NULL, 'No', 1, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', NULL, 'Yes', 'Yes', 'Yes', 'textarea1', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '', 'textarea2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 'q1', 'q2', 'q3', 'textarea3'),
(73, 73, 187, 68, NULL, 'No', 1, 'Yes', 'No', 'No', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', NULL, NULL, 'Yes', 'Yes', 'Yes', '×‘×›×œ×œ ×œ×', 'Yes', 'Yes', '', 'Yes', 'Yes', 'Yes', 'Yes', '×œ× ×”×¤×¢×', '', '', '', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'Yes', '×›××Ÿ ×•×©×', '×”×™×™×ª×™ ×•×¢×›×©×™×• ×œ×', '', '×‘×”×›×œ '),
(76, 76, 178, 88, NULL, 'No', 1, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', ''),
(77, 77, 158, 56, NULL, 'No', 8, NULL, NULL, NULL, NULL, '', 'Yes', '', '', '', '', '', '', NULL, NULL, '', '', 'Yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', ''),
(78, 78, 127, 178, NULL, 'No', 1, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', ''),
(79, 79, 122, 23, NULL, NULL, 1, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `user__status`
--

CREATE TABLE IF NOT EXISTS `user__status` (
  `us_id` int(11) NOT NULL auto_increment,
  `us_type` varchar(45) NOT NULL,
  PRIMARY KEY  (`us_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `user__status`
--

INSERT INTO `user__status` (`us_id`, `us_type`) VALUES
(1, 'Premium'),
(2, 'Subscription'),
(3, 'Free'),
(4, '6D'),
(5, 'Open'),
(6, 'Close');

-- --------------------------------------------------------

--
-- Структура таблицы `video__6d`
--

CREATE TABLE IF NOT EXISTS `video__6d` (
  `v6d_id` int(11) NOT NULL auto_increment,
  `v6d_code` varchar(250) NOT NULL,
  PRIMARY KEY  (`v6d_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `video__6d`
--

INSERT INTO `video__6d` (`v6d_id`, `v6d_code`) VALUES
(1, '<script type="text/javascript" src="http://content.bitsontherun.com/players/6ieFYyoc-YGFwoZEb.js"></script>'),
(2, '<script type="text/javascript" src="http://content.bitsontherun.com/players/rG3cKvxB-YGFwoZEb.js"></script>'),
(3, '<script type="text/javascript" src="http://content.bitsontherun.com/players/2F56y1mm-YGFwoZEb.js"></script>'),
(4, '<script type="text/javascript" src="http://content.bitsontherun.com/players/sYkRY82G-YGFwoZEb.js"></script>'),
(5, '<script type="text/javascript" src="http://content.bitsontherun.com/players/uxiHEHAX-YGFwoZEb.js"></script>'),
(6, '<script type="text/javascript" src="http://content.bitsontherun.com/players/ugCwXP6p-YGFwoZEb.js"></script>');

-- --------------------------------------------------------

--
-- Структура таблицы `video__6d_status`
--

CREATE TABLE IF NOT EXISTS `video__6d_status` (
  `v6ds_id` int(11) NOT NULL auto_increment,
  `v6ds_video_id` tinyint(3) NOT NULL,
  `v6ds_user_id` int(11) NOT NULL,
  `v6ds_teacher_id` int(11) NOT NULL,
  `v6ds_viewed` set('Yes','No') default 'No',
  `v6ds_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `v6ds_paused` set('Yes','No') default 'No',
  `v6ds_notified` set('Yes','No') default 'No',
  PRIMARY KEY  (`v6ds_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=186 ;

--
-- Дамп данных таблицы `video__6d_status`
--

INSERT INTO `video__6d_status` (`v6ds_id`, `v6ds_video_id`, `v6ds_user_id`, `v6ds_teacher_id`, `v6ds_viewed`, `v6ds_timestamp`, `v6ds_paused`, `v6ds_notified`) VALUES
(180, 1, 72, 1, 'Yes', '2011-04-14 19:23:50', 'No', 'Yes'),
(181, 2, 72, 1, 'Yes', '2011-04-14 19:24:37', 'No', 'Yes'),
(182, 3, 72, 1, 'Yes', '2011-04-14 19:25:16', 'No', 'Yes'),
(183, 4, 72, 1, 'Yes', '2011-04-14 19:26:21', 'No', 'Yes'),
(184, 5, 72, 1, 'Yes', '2011-04-14 19:36:30', 'No', 'Yes'),
(185, 6, 72, 1, 'Yes', '2011-04-14 19:37:27', 'No', 'No');

-- --------------------------------------------------------

--
-- Структура таблицы `video__all_movies`
--

CREATE TABLE IF NOT EXISTS `video__all_movies` (
  `vam_id` int(11) NOT NULL auto_increment,
  `vam_video_player1` varchar(250) default NULL,
  `vam_video_player2` text,
  `vam_teacher_id` int(11) NOT NULL,
  `vam_user_id` int(11) NOT NULL,
  `vam_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `vam_is_payed` set('Yes','No') default 'No',
  `vam_playing_duration` int(11) NOT NULL default '0',
  PRIMARY KEY  (`vam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

--
-- Дамп данных таблицы `video__all_movies`
--

INSERT INTO `video__all_movies` (`vam_id`, `vam_video_player1`, `vam_video_player2`, `vam_teacher_id`, `vam_user_id`, `vam_timestamp`, `vam_is_payed`, `vam_playing_duration`) VALUES
(78, 'cccccccw', NULL, 1, 72, '2011-04-15 12:16:36', 'No', 0),
(79, 'Tgh1Dujj', NULL, 1, 72, '2011-04-15 12:17:51', 'No', 0);
